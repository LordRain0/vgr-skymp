module.exports = (mp) => {
  const path = require("path");
  const crypto = require("crypto");
  const tradeHelpers = require(path.join(__dirname, "vgr_trade_helpers"));
  const {
    VGR_GOLD_BASE_ID,
    finalizeTrade,
    normalizeOffer,
    getItemCount,
    isTradableEntry,
  } = tradeHelpers;

  const LOG_TRADING = "[VGR trading]";
  const VGR_TRADING_UI_VERSION = 1;
  const VGR_TRADE_TIMEOUT_MS = 5 * 60 * 1000;
  const VGR_TRADE_PROXIMITY = 2000;

  // Dev: offline partner reference for single-client F4 testing.
  // formDesc is the MongoDB changeForms key (e.g. "1", "b") — NOT profileId.
  // runtimeFormId is only used when that actor is actually loaded in SkyMP memory.
  const VGR_TRADING_DEV = false;
  const DEBUG_PARTNER_FORM_DESC = "1";
  const DEBUG_PARTNER_DISPLAY_NAME = "Character 1 (offline)";
  const DEBUG_PARTNER_RUNTIME_FORM_ID = null;
  const DEBUG_PARTNER_OFFER = [{ baseId: VGR_GOLD_BASE_ID, count: 20 }];

  const vgrTradeSessions = new Map();
  const vgrPlayerTrade = new Map();

  const vgrMakeTradeId = () => "trade_" + Date.now() + "_" + crypto.randomBytes(9).toString("base64url");

  const vgrActorExists = (pcFormId) => {
    if (pcFormId == null || pcFormId === 0) return false;
    try {
      mp.get(pcFormId, "inventory");
      return true;
    } catch (e) {
      return false;
    }
  };

  const vgrGetInventory = (pcFormId) => {
    if (!vgrActorExists(pcFormId)) return { entries: [] };
    try {
      return mp.get(pcFormId, "inventory") || { entries: [] };
    } catch (e) {
      return { entries: [] };
    }
  };

  const vgrGetPlayerName = (pcFormId, fallback) => {
    if (!vgrActorExists(pcFormId)) return fallback || "Unknown Player";
    const keys = ["appearance", "appearanceDump"];
    for (let i = 0; i < keys.length; i++) {
      try {
        const data = mp.get(pcFormId, keys[i]);
        if (data && data.name) return String(data.name);
      } catch (e) { }
    }
    try {
      return mp.getDescFromId(pcFormId) || fallback || "Adventurer";
    } catch (e) {
      return fallback || "Adventurer";
    }
  };

  const vgrMapEspmType = (record) => {
    if (!record || !record.type) return "misc";
    const t = String(record.type).toUpperCase();
    if (t.indexOf("WEAP") !== -1) return "weapon";
    if (t.indexOf("ARMO") !== -1 || t.indexOf("ARMA") !== -1) return "armor";
    if (t.indexOf("ALCH") !== -1) return "potion";
    if (t.indexOf("INGR") !== -1) return "material";
    if (t.indexOf("MISC") !== -1) return "misc";
    return "misc";
  };

  const vgrEnrichItem = (entry) => {
    const baseId = entry.baseId;
    if (!baseId || baseId <= 0) return null;
    let name = "Item " + baseId.toString(16);
    let type = "misc";
    let description = "";

    try {
      const lookup = mp.lookupEspmRecordById(baseId);
      if (lookup && lookup.record) {
        if (lookup.record.fullName) name = String(lookup.record.fullName);
        else if (lookup.record.editorId) name = String(lookup.record.editorId);
        type = vgrMapEspmType(lookup.record);
      }
    } catch (e) { }

    return {
      id: String(baseId),
      name: name,
      type: type,
      qty: Number(entry.count) || 0,
      value: 0,
      weight: 0,
      description: description,
      baseId: baseId,
    };
  };

  const vgrSplitInventory = (inv) => {
    const entries = Array.isArray(inv.entries) ? inv.entries : [];
    let gold = 0;
    const items = [];

    for (const entry of entries) {
      if (!entry || typeof entry.baseId !== "number" || entry.baseId <= 0) continue;
      if (!isTradableEntry(entry)) continue;
      if (entry.baseId === VGR_GOLD_BASE_ID) {
        gold += Number(entry.count) || 0;
        continue;
      }
      const enriched = vgrEnrichItem(entry);
      if (enriched) items.push(enriched);
    }

    return { gold, items };
  };

  const vgrOfferToUiItems = (offer) => {
    return normalizeOffer(offer)
      .map((item) => vgrEnrichItem(item))
      .filter((item) => item != null);
  };

  const vgrGetGoldInOffer = (offer) => {
    const stack = normalizeOffer(offer).find((e) => e.baseId === VGR_GOLD_BASE_ID);
    return stack ? stack.count : 0;
  };

  const vgrSetGoldInOffer = (offer, gold) => {
    const next = normalizeOffer(offer).filter((e) => e.baseId !== VGR_GOLD_BASE_ID);
    const amount = Math.max(0, Math.floor(Number(gold) || 0));
    if (amount > 0) next.push({ baseId: VGR_GOLD_BASE_ID, count: amount });
    return next;
  };

  const vgrGetDistance = (a, b) => {
    if (!a || !b) return Infinity;
    const dx = (a[0] || 0) - (b[0] || 0);
    const dy = (a[1] || 0) - (b[1] || 0);
    const dz = (a[2] || 0) - (b[2] || 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  };

  const vgrPlayersNear = (a, b) => {
    if (VGR_TRADING_DEV) return true;
    try {
      const cellA = mp.get(a, "worldOrCellDesc");
      const cellB = mp.get(b, "worldOrCellDesc");
      if (!cellA || !cellB || cellA !== cellB) return false;
      const posA = mp.get(a, "pos");
      const posB = mp.get(b, "pos");
      return vgrGetDistance(posA, posB) <= VGR_TRADE_PROXIMITY;
    } catch (e) {
      return false;
    }
  };

  const vgrGetOnlinePlayerIds = () => {
    try {
      const online = mp.get(0xff000000, "onlinePlayers");
      return Array.isArray(online) ? online : [];
    } catch (e) {
      return [];
    }
  };

  const vgrFindNearestOnlinePlayer = (pcFormId) => {
    let nearestId = null;
    let nearestDist = Infinity;

    for (const otherId of vgrGetOnlinePlayerIds()) {
      if (otherId === pcFormId) continue;
      if (!vgrActorExists(otherId)) continue;
      if (!vgrPlayersNear(pcFormId, otherId)) continue;

      try {
        const posA = mp.get(pcFormId, "pos");
        const posB = mp.get(otherId, "pos");
        const dist = vgrGetDistance(posA, posB);
        if (dist < nearestDist) {
          nearestDist = dist;
          nearestId = otherId;
        }
      } catch (e) { }
    }

    return nearestId;
  };

  const vgrOpenOfflineDebugTrade = (pcFormId) => {
    const partnerId =
      DEBUG_PARTNER_RUNTIME_FORM_ID && vgrActorExists(DEBUG_PARTNER_RUNTIME_FORM_ID)
        ? DEBUG_PARTNER_RUNTIME_FORM_ID
        : null;
    let session = vgrCreateSession(pcFormId, partnerId, {
      partnerDisplayName: DEBUG_PARTNER_DISPLAY_NAME,
      partnerOffline: !partnerId,
      skipInitialPush: true,
    });
    if (!session) {
      const existing = vgrPlayerTrade.get(pcFormId);
      if (existing) session = vgrTradeSessions.get(existing);
    }
    if (session) {
      session.offerB = DEBUG_PARTNER_OFFER.map((e) => ({ ...e }));
      session.acceptedA = false;
      session.acceptedB = false;
      session.partnerDisplayName = DEBUG_PARTNER_DISPLAY_NAME;
      vgrPushBoth(session, "open", "grab", null);
    }
    return session;
  };

  const vgrOpenNearestTrade = (pcFormId) => {
    const nearestId = vgrFindNearestOnlinePlayer(pcFormId);
    if (!nearestId) return null;

    const session = vgrCreateSession(pcFormId, nearestId);
    if (session) {
      console.log(
        LOG_TRADING,
        "trade opened with nearest player:",
        nearestId,
        "(" + vgrGetPlayerName(nearestId, "Unknown") + ")"
      );
    } else {
      console.log(LOG_TRADING, "could not open trade with nearest player", nearestId);
    }
    return session;
  };

  const vgrForceCloseUiProperty = (pcFormId, reason) => {
    if (pcFormId == null || pcFormId === 0) return;
    try {
      mp.set(pcFormId, "vgrTradingUi", {
        version: VGR_TRADING_UI_VERSION,
        nonce: Date.now() + ":" + Math.random(),
        action: "close",
        focus: "release",
        reason: reason || "",
      });
    } catch (e) {
      console.warn(LOG_TRADING, "force close ui failed for", pcFormId, e);
    }
  };

  const vgrClearSession = (tradeId, reason) => {
    const session = vgrTradeSessions.get(tradeId);
    if (!session) return;

    if (session.timeout) clearTimeout(session.timeout);

    if (session.playerA) vgrForceCloseUiProperty(session.playerA, reason);
    if (session.playerB) vgrForceCloseUiProperty(session.playerB, reason);
	
    if (session.playerA) vgrPlayerTrade.delete(session.playerA);
    if (session.playerB) vgrPlayerTrade.delete(session.playerB);
    vgrTradeSessions.delete(tradeId);

    console.log(LOG_TRADING, "session cleared:", tradeId, reason || "");
  };

  const vgrResetAccept = (session) => {
    session.acceptedA = false;
    session.acceptedB = false;
    session.updatedAt = Date.now();
  };

  const vgrSubtractOfferFromItems = (items, offer) => {
    const offered = {};
    for (const o of normalizeOffer(offer)) {
      offered[o.baseId] = (offered[o.baseId] || 0) + o.count;
    }
    return items
      .map((item) => {
        const baseId = item.baseId != null ? item.baseId : Number(item.id);
        const take = offered[baseId] || 0;
        return { ...item, qty: Math.max(0, item.qty - take) };
      })
      .filter((item) => item.qty > 0);
  };

  const vgrBuildUiPayload = (session, pcFormId, action, focus) => {
    const isA = pcFormId === session.playerA;
    const selfOffer = isA ? session.offerA : session.offerB;
    const otherOffer = isA ? session.offerB : session.offerA;
    const selfAccepted = isA ? session.acceptedA : session.acceptedB;
    const partnerAccepted = isA ? session.acceptedB : session.acceptedA;
    const partnerId = session.partnerOffline
      ? null
      : isA
        ? session.playerB
        : session.playerA;

    const selfInv = vgrSplitInventory(vgrGetInventory(pcFormId));
    const partnerOnline = partnerId != null && vgrActorExists(partnerId);
    const partnerInv = partnerOnline
      ? vgrSplitInventory(vgrGetInventory(partnerId))
      : { gold: 0, items: [] };
    const selfGoldOffer = vgrGetGoldInOffer(selfOffer);
    const partnerDisplayName = session.visibleNames && session.visibleNames[pcFormId]
      ? session.visibleNames[pcFormId]
      : session.partnerDisplayName || "Trade Partner";

    return {
      version: VGR_TRADING_UI_VERSION,
      nonce: Date.now() + ":" + Math.random(),
      action: action,
      focus: focus || null,
      tradeId: session.id,
      playerName: vgrGetPlayerName(pcFormId, "Adventurer"),
      partnerName: partnerDisplayName,
      playerGold: Math.max(0, selfInv.gold - selfGoldOffer),
      partnerGold: partnerInv.gold,
      playerItems: vgrSubtractOfferFromItems(selfInv.items, selfOffer),
      playerOffer: vgrOfferToUiItems(selfOffer),
      partnerOffer: vgrOfferToUiItems(otherOffer),
      partnerGoldOffer: vgrGetGoldInOffer(otherOffer),
      playerGoldOffer: selfGoldOffer,
      selfAccepted: selfAccepted,
      partnerAccepted: partnerAccepted,
    };
  };

  const vgrPushUi = (pcFormId, extra, focus) => {
    if (!vgrActorExists(pcFormId)) return;
    try {
      const tradeId = vgrPlayerTrade.get(pcFormId);
      if (!tradeId) {
        if (extra && extra.action === "close") {
          mp.set(pcFormId, "vgrTradingUi", {
            version: VGR_TRADING_UI_VERSION,
            nonce: Date.now() + ":" + Math.random(),
            action: "close",
            focus: focus || "release",
          });
        }
        return;
      }

      const session = vgrTradeSessions.get(tradeId);
      if (!session) return;

      const action = (extra && extra.action) || "update";
      const payload = vgrBuildUiPayload(session, pcFormId, action, focus);
      mp.set(pcFormId, "vgrTradingUi", payload);
    } catch (e) {
      console.error(LOG_TRADING, "pushUi failed:", e);
    }
  };

  const vgrPushBoth = (session, action, focusA, focusB) => {
    vgrPushUi(session.playerA, { action: action }, focusA || null);
    if (session.playerB && vgrActorExists(session.playerB)) {
      vgrPushUi(session.playerB, { action: action }, focusB || null);
    }
  };

  const vgrStartTimeout = (session) => {
    if (session.timeout) clearTimeout(session.timeout);
    session.timeout = setTimeout(() => {
      vgrClearSession(session.id, "timeout");
    }, VGR_TRADE_TIMEOUT_MS);
  };

  const vgrCreateSession = (playerA, playerB, options) => {
    const opts = options || {};
    if (vgrPlayerTrade.has(playerA)) return null;
    if (playerB && vgrActorExists(playerB) && vgrPlayerTrade.has(playerB)) return null;
    if (playerB && !vgrPlayersNear(playerA, playerB) && !VGR_TRADING_DEV) return null;

    const tradeId = vgrMakeTradeId();
    const partnerOffline = !!(opts.partnerOffline || !playerB || !vgrActorExists(playerB));
    const session = {
      id: tradeId,
      playerA: playerA,
      playerB: partnerOffline ? null : playerB,
      partnerDisplayName: opts.partnerDisplayName || "Trade Partner",
      visibleNames: opts.visibleNames || null,
      partnerOffline: partnerOffline,
      offerA: [],
      offerB: [],
      acceptedA: false,
      acceptedB: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      timeout: null,
    };

    vgrTradeSessions.set(tradeId, session);
    vgrPlayerTrade.set(playerA, tradeId);
    if (playerB && vgrActorExists(playerB)) {
      vgrPlayerTrade.set(playerB, tradeId);
    }
    vgrStartTimeout(session);

    if (!opts.skipInitialPush) {
      vgrPushBoth(session, "open", "grab", "grab");
    }
    console.log(
      LOG_TRADING,
      "session created:",
      tradeId,
      "playerA=" + playerA,
      "playerB=" + session.playerB,
      session.partnerOffline ? "(partner offline)" : ""
    );
    return session;
  };

  const vgrAddToOffer = (session, pcFormId, baseId, count) => {
    const isA = pcFormId === session.playerA;
    const offerKey = isA ? "offerA" : "offerB";
    const inv = vgrGetInventory(pcFormId);
    const amount = Math.max(1, Math.floor(Number(count) || 1));

    if (baseId === VGR_GOLD_BASE_ID) return false;
    if (getItemCount(inv, baseId) < amount) return false;

    const offer = normalizeOffer(session[offerKey]);
    const existing = offer.find((e) => e.baseId === baseId);
    const alreadyOffered = existing ? existing.count : 0;
    if (getItemCount(inv, baseId) < alreadyOffered + amount) return false;

    if (existing) {
      existing.count += amount;
    } else {
      offer.push({ baseId: baseId, count: amount });
    }

    session[offerKey] = offer;
    vgrResetAccept(session);
    return true;
  };

  const vgrRemoveFromOffer = (session, pcFormId, baseId, count) => {
    const isA = pcFormId === session.playerA;
    const offerKey = isA ? "offerA" : "offerB";
    const amount = Math.max(1, Math.floor(Number(count) || 1));
    const offer = normalizeOffer(session[offerKey]);
    const idx = offer.findIndex((e) => e.baseId === baseId);
    if (idx === -1) return false;

    offer[idx].count -= amount;
    if (offer[idx].count <= 0) offer.splice(idx, 1);
    session[offerKey] = offer;
    vgrResetAccept(session);
    return true;
  };

  const vgrClearOffer = (session, pcFormId) => {
    const isA = pcFormId === session.playerA;
    session[isA ? "offerA" : "offerB"] = [];
    vgrResetAccept(session);
  };

  const vgrSetOfferGold = (session, pcFormId, gold) => {
    const isA = pcFormId === session.playerA;
    const offerKey = isA ? "offerA" : "offerB";
    const inv = vgrGetInventory(pcFormId);
    const maxGold = getItemCount(inv, VGR_GOLD_BASE_ID);
    const amount = Math.max(0, Math.min(Math.floor(Number(gold) || 0), maxGold));
    session[offerKey] = vgrSetGoldInOffer(session[offerKey], amount);
    vgrResetAccept(session);
  };

  const vgrTryFinalize = (session) => {
    if (!session.acceptedA || !session.acceptedB) return false;
    if (session.partnerOffline || !vgrActorExists(session.playerB)) {
      console.error(
        LOG_TRADING,
        "cannot finalize: partner offline (formDesc " +
        DEBUG_PARTNER_FORM_DESC +
        "). Use tools/debug-force-trade.js instead."
      );
      vgrResetAccept(session);
      vgrPushBoth(session, "update");
      return false;
    }

    const invA = vgrGetInventory(session.playerA);
    const invB = vgrGetInventory(session.playerB);

    try {
      const result = finalizeTrade(invA, invB, session.offerA, session.offerB);
      mp.set(session.playerA, "inventory", result.invA);
      mp.set(session.playerB, "inventory", result.invB);
      console.log(LOG_TRADING, "trade finalized:", session.id);
      vgrClearSession(session.id, "completed");
      return true;
    } catch (e) {
      console.error(LOG_TRADING, "finalize failed:", e.message || e);
      vgrResetAccept(session);
      vgrPushBoth(session, "update");
      return false;
    }
  };

  mp.makeProperty("vgrTradingUi", {
    isVisibleByOwner: true,
    isVisibleByNeighbors: false,
    updateOwner: `
      const value = ctx.value;

      if (!ctx.state.vgrTradingUi) {
        ctx.state.vgrTradingUi = { lastNonce: null };
      }

      if (!value || value.version !== ${VGR_TRADING_UI_VERSION}) {
        return;
      }

      if (ctx.state.vgrTradingUi.lastNonce === value.nonce) {
        return;
      }
      ctx.state.vgrTradingUi.lastNonce = value.nonce;

      if (!ctx.state.vgrTrading) {
        ctx.state.vgrTrading = { isOpen: false };
      }

      if (value.focus === "grab") {
        //ctx.sp.browser.executeJavaScript('window.vgrHideActiveUI && window.vgrHideActiveUI()');
        ctx.sp.browser.executeJavaScript('window.skyrimPlatform?.sendMessage?.("vgr:ui:open", "trading")');
		ctx.state.vgrTrading.isOpen = true;
      }

      if (value.action === "open") {
        ctx.state.vgrTrading.isOpen = true;
      } else if (value.action === "close") {
        ctx.state.vgrTrading.isOpen = false;
      }

      ctx.sp.browser.executeJavaScript(
        "window.vgrTradingUpdate && window.vgrTradingUpdate(" + JSON.stringify(value) + ");"
      );

      if (value.focus === "release") {
        ctx.sp.browser.executeJavaScript('window.skyrimPlatform?.sendMessage?.("vgr:ui:close", "trading")');
		ctx.state.vgrTrading.isOpen = false;
      }
    `,
    updateNeighbor: "",
  });

  mp.makeEventSource("_vgrTrading", `
    ctx.sp.printConsole("[VGR trading] event source loaded");

    if (!ctx.state.vgrTrading) {
      ctx.state.vgrTrading = { isOpen: false };
    }

    const closeTradingUi = (reason) => {
      if (!ctx.state.vgrTrading.isOpen) return;
      ctx.state.vgrTrading.isOpen = false;
      ctx.sp.printConsole("[VGR trading] close requested: " + reason);
      ctx.sendEvent({ kind: "cancel", reason: reason });
    };

    ctx.sp.on("buttonEvent", (e) => {
      if (!e.isPressed) return;
      if (ctx.state.vgrTrading.isOpen && e.code === 1) {
        closeTradingUi("escape");
        return;
      }
      // F4 = 62 — open trade with nearest online player (offline dev fallback when enabled)
      if (e.code === 62 && ${VGR_TRADING_DEV ? "true" : "false"}) {
        ctx.sendEvent({ kind: "nearestOpen" });
      }
    });

    ctx.sp.on("browserMessage", (e) => {
      const msg = e.arguments && e.arguments[0];
      const payload = e.arguments && e.arguments[1];

      if (msg === "vgr:trading:addOffer") {
        ctx.sendEvent({ kind: "addOffer", payload: payload });
      } else if (msg === "vgr:trading:removeOffer") {
        ctx.sendEvent({ kind: "removeOffer", payload: payload });
      } else if (msg === "vgr:trading:clearOffer") {
        ctx.sendEvent({ kind: "clearOffer" });
      } else if (msg === "vgr:trading:offerGold") {
        ctx.sendEvent({ kind: "offerGold", payload: payload });
      } else if (msg === "vgr:trading:accept") {
        ctx.sendEvent({ kind: "accept", payload: payload });
      } else if (msg === "vgr:trading:cancel") {
        ctx.sendEvent({ kind: "cancel", payload: payload });
      } else if (msg === "vgr:trading:request") {
        ctx.sendEvent({ kind: "request", payload: payload });
      } else if (msg === "vgr:trading:debugOpen") {
        ctx.sendEvent({ kind: "debugOpen" });
      }
      //When ui gets closed by any source, close active sessions
      if (msg === "vgr:ui:on_close") {
        const name_ui = e.arguments && e.arguments[1]; // Get the name of UI thats being closed
        if (name_ui === "trading") {
          ctx.sendEvent({ kind: "cancel", payload: payload });
        }
      }
    });
  `);

  mp._vgrTrading = (pcFormId, payload) => {
    if (!payload) return;

    if (payload.kind === "nearestOpen") {
      if (vgrOpenNearestTrade(pcFormId)) return;

      if (VGR_TRADING_DEV) {
        vgrOpenOfflineDebugTrade(pcFormId);
        return;
      }

      console.log(
        LOG_TRADING,
        "no nearby online player to trade with (same cell, within",
        VGR_TRADE_PROXIMITY,
        "units)"
      );
      return;
    }

    if (payload.kind === "debugOpen") {
      if (!VGR_TRADING_DEV) return;
      vgrOpenOfflineDebugTrade(pcFormId);
      return;
    }

    if (payload.kind === "request") {
      if (!VGR_TRADING_DEV) {
        console.warn(LOG_TRADING, "direct browser trade request ignored in production mode");
        return;
      }
      const targetId = payload.payload && Number(payload.payload.targetFormId);
      if (!targetId || targetId === pcFormId) {
        if (vgrOpenNearestTrade(pcFormId)) return;
        console.log(LOG_TRADING, "trade request missing targetFormId and no nearby player found");
        return;
      }
      vgrCreateSession(pcFormId, targetId);
      return;
    }

    const tradeId = vgrPlayerTrade.get(pcFormId);
    if (!tradeId) return;
    const session = vgrTradeSessions.get(tradeId);
    if (!session) return;

    if (payload.kind === "cancel") {
      vgrClearSession(tradeId, (payload.payload && payload.payload.reason) || "cancel");
      return;
    }

    if (payload.kind === "addOffer") {
      const p = payload.payload || {};
      const baseId = Number(p.baseId != null ? p.baseId : p.itemId);
      const count = Number(p.count || p.qty || 1);
      if (!Number.isFinite(baseId)) return;
      if (vgrAddToOffer(session, pcFormId, baseId, count)) {
        vgrPushBoth(session, "update");
      }
      return;
    }

    if (payload.kind === "removeOffer") {
      const p = payload.payload || {};
      const baseId = Number(p.baseId != null ? p.baseId : p.itemId);
      const count = Number(p.count || p.qty || 1);
      if (!Number.isFinite(baseId)) return;
      if (vgrRemoveFromOffer(session, pcFormId, baseId, count)) {
        vgrPushBoth(session, "update");
      }
      return;
    }

    if (payload.kind === "clearOffer") {
      vgrClearOffer(session, pcFormId);
      vgrPushBoth(session, "update");
      return;
    }

    if (payload.kind === "offerGold") {
      const gold = payload.payload && payload.payload.gold;
      vgrSetOfferGold(session, pcFormId, gold);
      vgrPushBoth(session, "update");
      return;
    }

    if (payload.kind === "accept") {
      const accepted = !!(payload.payload && payload.payload.accepted);
      if (pcFormId === session.playerA) session.acceptedA = accepted;
      else if (session.playerB && pcFormId === session.playerB) session.acceptedB = accepted;
      session.updatedAt = Date.now();

      if (VGR_TRADING_DEV && accepted && session.partnerOffline) {
        session.acceptedA = true;
        session.acceptedB = true;
      } else if (VGR_TRADING_DEV && accepted && session.playerB) {
        let partnerOnline = false;
        try {
          const online = mp.get(0xff000000, "onlinePlayers");
          const partnerId = pcFormId === session.playerA ? session.playerB : session.playerA;
          partnerOnline = Array.isArray(online) && online.indexOf(partnerId) !== -1;
        } catch (e) { }
        if (!partnerOnline) {
          session.acceptedA = true;
          session.acceptedB = true;
        }
      }

      vgrPushBoth(session, "update");
      vgrTryFinalize(session);
      return;
    }
  };

  mp._vgrTradingApi = {
    requestExactTargetTrade(requesterPcFormId, targetPcFormId, context) {
      const requester = Number(requesterPcFormId);
      const target = Number(targetPcFormId);
      if (!Number.isInteger(requester) || !Number.isInteger(target) || requester <= 0 || target <= 0) return null;
      if (requester === target) return null;
      return vgrCreateSession(requester, target, {
        partnerDisplayName: context && context.partnerDisplayName,
        visibleNames: context && context.visibleNames,
      });
    },
    isTrading(pcFormId) {
      return vgrPlayerTrade.has(Number(pcFormId));
    },
    cancelForActor(pcFormId, reason) {
      const tradeId = vgrPlayerTrade.get(Number(pcFormId));
      if (tradeId) vgrClearSession(tradeId, reason || "cancel");
    },
  };

  mp._vgrTradingDebugFinalize = (pcFormIdA, partnerFormId, offerA, offerB) => {
    if (!VGR_TRADING_DEV) return false;
    if (!vgrActorExists(partnerFormId)) {
      console.error(
        LOG_TRADING,
        "partner actor not loaded (formDesc " +
        DEBUG_PARTNER_FORM_DESC +
        "); use tools/debug-force-trade.js"
      );
      return false;
    }
    const invA = vgrGetInventory(pcFormIdA);
    const invB = vgrGetInventory(partnerFormId);
    if (!invB.entries || invB.entries.length === 0) {
      console.error(LOG_TRADING, "partner inventory empty; use Mongo debug script");
      return false;
    }
    try {
      const result = finalizeTrade(invA, invB, offerA, offerB);
      mp.set(pcFormIdA, "inventory", result.invA);
      mp.set(partnerFormId, "inventory", result.invB);
      console.log(LOG_TRADING, "debug finalize OK");
      return true;
    } catch (e) {
      console.error(LOG_TRADING, "debug finalize failed:", e.message || e);
      return false;
    }
  };

  mp.on("connect", (pcFormId) => {
    try {
      vgrForceCloseUiProperty(pcFormId, "login");
    } catch (e) { }
  });

  mp.on("disconnect", (pcFormId) => {
    try {
      const tradeId = vgrPlayerTrade.get(pcFormId);
      if (tradeId) {
        vgrClearSession(tradeId, "disconnect");
      } else {
        vgrForceCloseUiProperty(pcFormId, "disconnect");
      }
    } catch (e) { }
  });

  console.log(LOG_TRADING, "module loaded", VGR_TRADING_DEV ? "(dev mode)" : "");
};
